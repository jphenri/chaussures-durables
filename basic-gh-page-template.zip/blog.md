---
layout: page
title: Blog
lang: fr
lang_ref: blog
permalink: /blog/
---
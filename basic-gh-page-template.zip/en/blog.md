---
layout: page
title: Blog
lang: en
lang_ref: blog
permalink: /en/blog/
---
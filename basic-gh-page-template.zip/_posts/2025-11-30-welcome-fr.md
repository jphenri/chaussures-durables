---
title: Bienvenue
lang: fr
---
Ceci est un article exemple.